class Uf < ApplicationRecord
end
